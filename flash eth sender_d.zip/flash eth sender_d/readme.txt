<!!--------READ ME FILE-----------!!>

1, Open the send.html file.
2, Enter a valid Ethereum Address.
3, Enter the Ethereum Amount.
4, Select Main Network or Test Network.
5, Click on the send fake ethereum button to send a flash/fake ethereum transaction.



NOTE TO START SENDING FAKE/FLASH BITCOIN TRANSACTION YOU MUST FIRST UNLOCK YOUR ACCOUNT TO GET A VALID AUTHENTICATION KEY..!!